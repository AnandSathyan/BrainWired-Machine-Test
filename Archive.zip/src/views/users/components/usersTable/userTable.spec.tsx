const useTableSpec = () => {};
export default useTableSpec;
