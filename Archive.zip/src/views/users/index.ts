import UsersView from "./users";

export default UsersView;
