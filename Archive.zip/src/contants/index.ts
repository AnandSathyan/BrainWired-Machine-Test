export const JSON_PLACEHOLDER = "https://jsonplaceholder.typicode.com";
